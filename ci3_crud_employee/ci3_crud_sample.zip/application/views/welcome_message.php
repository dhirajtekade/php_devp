<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
   <!-- <link href="css/bootstrap.min.css" rel="stylesheet">
	--><!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	<div class="row">
		<div class="container" style="max-width:500px !important; margin:0 auto;" >		
			<div class="col-sm-12">
				<div class="alert alert-danger" role="alert">
				  <?php  echo validation_errors(); ?>
				</div>
			</div>
		</div>
	</div>
	
	<?php echo form_open(base_url().'index.php/welcome/validate', '', $hidden=array());?>
	
	<div class="row">
		<div class="container">
			<div class="col-sm-12">
				<div class="form-group">
					<?php 
					echo form_label('Firstname','firstname',$attribute=array());
					?>
					<?php 
					echo form_input('firstname', set_value('firstname'), $attribute=array("class"=>"form-control","id"=>"firstname"));
					?>
				</div>
				
				<div class="form-group">
					<?php 
					echo form_label('Second name','secondname',$attribute=array());
					?>
					<?php 
					echo form_input('secondname', set_value('secondname'), $attribute=array("class"=>"form-control","id"=>"secondname"));
					?>
				</div>
				
				<div class="form-group">
					<?php 
					echo form_label('Gender','gender',$attribute=array());
					?>
					<?php
						$options = array(
							""=>"Choose gender",
							"male"=>"Male",
							"female"=>"Female"
						);
					?>
					<?php 
					echo form_dropdown('gender', $options, set_value('gender'), array("class"=>"form-control","id"=>"gender"));
					?>
				</div>
				
				<div class="form-group">
				<?php echo form_label('How did you hear about us?', '', $attribute=array()); ?>
				<div class="checkbox">
					<label>
					  <?php echo form_checkbox("how_did_you_hear[]", "Search engine", set_checkbox("how_did_you_hear[]", "Search engine")); ?>Search engine
					</label>
				</div>
				<div class="checkbox">
					<label>
					  <?php echo form_checkbox("how_did_you_hear[]", "News paper advertisement", set_checkbox("how_did_you_hear[]", "News paper advertisement")); ?>News paper
					</label>
				</div>
				<div class="checkbox">
					<label>
					  <?php echo form_checkbox("how_did_you_hear[]", "Social network", set_checkbox("how_did_you_hear[]", "Social network")); ?>Social Network
					</label>
				</div>
				<div class="checkbox">
					<label>
					  <?php echo form_checkbox("how_did_you_hear[]", "Forum and blog", set_checkbox("how_did_you_hear[]", "Forum and blog")); ?>Forum and blog
					</label>
				</div>
				</div>
				
				<div class="form-group">
				<?php echo form_label('Preferred Contact type', '', $attribute=array()); ?>
				<div class="radio">
					<label>
					  <?php echo  form_radio("preferred_contact_type", "E-mail", set_radio("preferred_contact_type", "E-mail")); ?>E-mail
					</label>
				</div>
				<div class="radio">
					<label>
					  <?php echo form_radio("preferred_contact_type", "Telephone", set_radio("preferred_contact_type", "Forum and blog")); ?>Telephone
					</label>
				</div>
				<div class="radio">
					<label>
					  <?php echo form_radio("preferred_contact_type", "By post", set_radio("preferred_contact_type", "Forum and blog")); ?>By Post
					</label>
				</div>
				</div>
				
				<div class="form-group">
					<?php echo form_label("Message", "message", $attribute=array()); ?>
					<?php echo form_textarea("message", set_value('message'), array("class"=>"form-control", "id"=>"message")); ?>
				</div>
				
				<div class="form-group">
					<?php echo form_submit('submit', 'Submit', array("class"=>"btn-primary btn-lg", "id"=>"submit"));?>
				</div>
				
				
			</div>
			
		</div>
		<?php echo form_close(); ?>
	</div>
	
	
	
	
	
	
	
	
	

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!-- <script src="js/bootstrap.min.js"></script>-->
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  </body>
</html>