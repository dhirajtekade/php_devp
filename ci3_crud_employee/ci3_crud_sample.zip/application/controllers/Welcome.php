<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}
	
	public function validate()
	{
		$this->form_validation->set_rules(
		'firstname',
		'','required',array("required"=>"First name is required")
		);
		$this->form_validation->set_rules(
		'secondname',
		'','required',array("required"=>"Second name is required")
		);
		$this->form_validation->set_rules(
		'gender',
		'','required',array("required"=>"Please choose the Gender")
		);
		$this->form_validation->set_rules(
		'how_did_you_hear[]',
		'','required',array("required"=>"Please select the How did you hear about us field")
		);
		$this->form_validation->set_rules(
		'preferred_contact_type',
		'','required',array("required"=>"Please choose the Preferred Contact Type"));
		$this->form_validation->set_rules(
		'message',
		'','required',array("required"=>"Please enter something into message box")
		);
		
		
		if($this->form_validation->run() == FALSE) {
			//
			$this->load->view('welcome_message');
		}else {
			//store things into the database
			$data = array(
			"firstname" =>$this->input->post('firstname'),
			"secondname" =>$this->input->post('secondname'),
			"gender"=> $this->input->post('gender'),
			"how_did_you_hear"=> implode(",", $this->input->post('how_did_you_hear')),
			"preferred_contact_type"=> $this->input->post('preferred_contact_type'),
			"message"=> $this->input->post('message')
			);
		}
		
		//$this->load->view('welcome_message');
	}
}
