<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('user_model','m');
	}
	public function index()
	{
		$this->load->view('layout/header');
		$this->load->view('user/index');
		$this->load->view('layout/footer');
	}
	
	public function showAllUser(){
		$result = $this->m->showAllUser();
		echo json_encode($result);
	}
	
	public function addUser(){
		$result = $this->m->addUser();
		$msg['success'] = false;
		$msg['type'] = 'add';
		if($result){
			$msg['success'] = true;
		} 
		echo json_encode($msg);
	}
	
	public function editEmployee(){
		$result = $this->m->editEmployee();
		echo json_encode($result);
	}
	
	public function updateEmployee(){
		$result = $this->m->updateEmployee();
		$msg['success'] = false;
		$msg['type'] = 'update';
		if($result) {
			$msg['success'] = true;
		}
		echo json_encode($msg);
	}
	public function deleteUser(){
		$result = $this->m->deleteUser();
		$msg['success'] = false;
		if($result) {
			$msg['success'] = true;
		}
		echo json_encode($msg);
	}
	
	
}
