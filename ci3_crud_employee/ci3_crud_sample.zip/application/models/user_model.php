<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
 public function showAllUser(){
	 $this->db->order_by('id','desc');
	$query = $this->db->get('tbl_users');
	if($query->num_rows() > 0) {
		return $query->result();
	} else {
		return false;
	}
 }
 
 public function addUser(){
	 $field = array(
			'name' => $this->input->post('txtUserName'),
			'subject' => $this->input->post('txtSubject'),
			'gender'=> $this->input->post('txtGender')
			);
		$this->db->insert('tbl_users',$field);
		if($this->db->affected_rows() > 0 ){
			return true;
		}else{
			return false;
		}
 }
 
 public function editEmployee(){
	 $id = $this->input->get('id');
	 $this->db->where('id',$id);
	 $query = $this->db->get('tbl_users');
	 if($query->num_rows() > 0){
		 return $query->row();
	 }else{
		 return false;
	 }
 }
 
 public function updateEmployee(){
		$id = $this->input->post('txtId');
		$field = array(
			'name' => $this->input->post('txtUserName'),
			'subject' => $this->input->post('txtSubject'),
			'gender'=> $this->input->post('txtGender')
			);
		$this->db->where('id',$id);
		$this->db->update('tbl_users', $field);
		if($this->db->affected_rows() > 0 ){
			return true;
		}else{
			return false;
		}
 }
 
 public function deleteEmployee(){
	 $id = $this->input->get('id');
	 $this->db->where('id',$id);
	 $this->db->delete('tbl_users');
	 if($this->db->affected_rows() > 0 ){
			return true;
		}else{
			return false;
		}
 }
}



